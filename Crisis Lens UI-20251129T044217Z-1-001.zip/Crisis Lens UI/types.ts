export interface ChatMessage {
  id: string;
  role: 'user' | 'model';
  text: string;
  timestamp: Date;
}

export type Tab = 'Home' | 'Alerts' | 'Profile';

export interface UserLocation {
  lat: number;
  lng: number;
  city: string;
  area: string;
}