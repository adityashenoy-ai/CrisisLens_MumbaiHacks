
import React from 'react';

export interface VerificationProps {
  crisisId: string;
  sourcesCount: number;
  lastVerified: string;
  severity?: "Critical" | "High" | "Moderate" | "Low";
}

const VerificationPanel: React.FC<{ verification: VerificationProps }> = ({ verification }) => {
  
  const getTimeDiff = (isoString: string) => {
    try {
      const diff = Date.now() - new Date(isoString).getTime();
      const mins = Math.floor(diff / 60000);
      if (mins < 1) return 'Just now';
      if (mins < 60) return `${mins}m ago`;
      const hours = Math.floor(mins / 60);
      return `${hours}h ago`;
    } catch {
      return 'Recently';
    }
  };

  const getSeverityStyle = (severity?: string) => {
    switch (severity) {
      case "Critical": return "bg-red-50 text-red-700 border-red-100";
      case "High": return "bg-orange-50 text-orange-700 border-orange-100";
      case "Moderate": return "bg-yellow-50 text-yellow-700 border-yellow-100";
      case "Low": return "bg-green-50 text-green-700 border-green-100";
      default: return "bg-slate-50 text-slate-600 border-slate-100";
    }
  };

  return (
    <div className="bg-white rounded-2xl border border-slate-200 p-4 shadow-sm">
      <div className="flex items-start justify-between">
        <div className="flex gap-3">
          {/* Minimal Icon */}
          <div className="mt-0.5 text-blue-600 flex-shrink-0">
            <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="currentColor" className="w-5 h-5">
              <path fillRule="evenodd" d="M8.603 3.799A4.49 4.49 0 0112 2.25c1.357 0 2.573.6 3.397 1.549a4.49 4.49 0 013.498 1.307 4.491 4.491 0 011.307 3.497A4.49 4.49 0 0121.75 12a4.49 4.49 0 01-1.549 3.397 4.491 4.491 0 01-1.307 3.497 4.491 4.491 0 01-3.497 1.307A4.49 4.49 0 0112 21.75a4.49 4.49 0 01-3.397-1.549 4.49 4.49 0 01-3.498-1.306 4.491 4.491 0 01-1.307-3.498A4.49 4.49 0 012.25 12c0-1.357.6-2.573 1.549-3.397a4.49 4.49 0 011.307-3.497 4.49 4.49 0 013.497-1.307zm4.45 6.45l-3.25 3.25a.75.75 0 01-1.06 0l-1.5-1.5a.75.75 0 111.06-1.06l.97.97 2.72-2.72a.75.75 0 111.06 1.06z" clipRule="evenodd" />
            </svg>
          </div>
          
          <div>
            <h3 className="text-sm font-bold text-slate-900 leading-none">Verified Update</h3>
            <div className="flex items-center gap-1.5 mt-1.5 text-xs font-medium text-slate-500">
              <span className="text-blue-700 bg-blue-50 px-1.5 py-0.5 rounded">AI Confirmed</span>
              <span className="text-slate-300">•</span>
              <span>{verification.sourcesCount} sources</span>
              <span className="text-slate-300">•</span>
              <span>{getTimeDiff(verification.lastVerified)}</span>
            </div>
          </div>
        </div>

        {/* Severity Badge */}
        {verification.severity && (
          <span className={`px-2.5 py-1 rounded-lg text-[10px] font-bold uppercase tracking-wide border ${getSeverityStyle(verification.severity)}`}>
            {verification.severity}
          </span>
        )}
      </div>
    </div>
  );
};

export default VerificationPanel;
