import React, { useState } from 'react';

const Switch: React.FC<{ checked: boolean; onChange: () => void }> = ({ checked, onChange }) => (
  <button 
    onClick={onChange}
    className={`w-12 h-7 rounded-full relative transition-colors duration-200 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-blue-500 ${checked ? 'bg-blue-600' : 'bg-slate-200'}`}
  >
    <span className={`block w-6 h-6 bg-white rounded-full shadow-sm transform transition-transform duration-200 absolute top-0.5 ${checked ? 'translate-x-[22px]' : 'translate-x-0.5'}`} />
  </button>
);

const ProfileScreen: React.FC = () => {
  const [notifications, setNotifications] = useState({
    crisis: true,
    location: true,
    criticalOnly: false,
    silentNight: false
  });

  const toggle = (key: keyof typeof notifications) => {
    setNotifications(prev => ({ ...prev, [key]: !prev[key] }));
  };

  return (
    <div className="min-h-screen bg-slate-50 pb-24 animate-in fade-in duration-300">
      {/* Header */}
      <header className="bg-white sticky top-0 z-10 border-b border-slate-100 px-4 py-4 flex items-center justify-between shadow-sm">
        <h1 className="text-xl font-bold text-slate-800">Profile</h1>
        <button className="text-blue-600 text-sm font-semibold px-3 py-1 rounded-full hover:bg-blue-50 transition-colors">
          Edit
        </button>
      </header>
      
      <div className="p-4 space-y-6">
        {/* User Card */}
        <div className="bg-white p-5 rounded-2xl shadow-sm border border-slate-100 flex items-center gap-5">
            <div className="w-16 h-16 rounded-full bg-slate-100 border border-slate-200 flex items-center justify-center text-3xl shadow-inner">
                👤
            </div>
            <div className="flex-1">
                <h2 className="font-bold text-slate-900 text-lg">John Doe</h2>
                <p className="text-slate-500 text-sm mb-1">+91 98765 43210</p>
                <button className="text-xs font-medium text-blue-600 border border-blue-200 px-3 py-1 rounded-lg hover:bg-blue-50 transition-colors">
                  Edit Profile
                </button>
            </div>
        </div>

        {/* Notification Settings */}
        <section className="bg-white rounded-2xl shadow-sm border border-slate-100 overflow-hidden">
            <h3 className="px-5 py-3 bg-slate-50/50 border-b border-slate-100 font-semibold text-slate-700 text-sm tracking-wide">NOTIFICATIONS</h3>
            <div className="divide-y divide-slate-100">
                <div className="p-4 flex items-center justify-between hover:bg-slate-50/50 transition-colors">
                    <div className="pr-4">
                        <p className="text-slate-900 font-medium">Crisis alerts</p>
                        <p className="text-xs text-slate-500 mt-0.5">Get notified immediately about new verified incidents</p>
                    </div>
                    <Switch checked={notifications.crisis} onChange={() => toggle('crisis')} />
                </div>
                
                <div className="p-4 flex items-center justify-between hover:bg-slate-50/50 transition-colors">
                    <div className="pr-4">
                        <p className="text-slate-900 font-medium">Location-based alerts</p>
                        <p className="text-xs text-slate-500 mt-0.5">Only notify for crises near my current location</p>
                    </div>
                    <Switch checked={notifications.location} onChange={() => toggle('location')} />
                </div>

                <div className="p-4 flex items-center justify-between hover:bg-slate-50/50 transition-colors">
                    <div className="pr-4">
                        <p className="text-slate-900 font-medium">Critical severity only</p>
                        <p className="text-xs text-slate-500 mt-0.5">Filter out Low and Moderate severity alerts</p>
                    </div>
                    <Switch checked={notifications.criticalOnly} onChange={() => toggle('criticalOnly')} />
                </div>

                <div className="p-4 flex items-center justify-between hover:bg-slate-50/50 transition-colors">
                    <div className="pr-4">
                        <p className="text-slate-900 font-medium">Silent mode at night</p>
                        <p className="text-xs text-slate-500 mt-0.5">Mute non-critical alerts from 10 PM to 7 AM</p>
                    </div>
                    <Switch checked={notifications.silentNight} onChange={() => toggle('silentNight')} />
                </div>
            </div>
        </section>

        {/* Location Preferences */}
        <section className="bg-white rounded-2xl shadow-sm border border-slate-100 overflow-hidden">
             <h3 className="px-5 py-3 bg-slate-50/50 border-b border-slate-100 font-semibold text-slate-700 text-sm tracking-wide">LOCATION</h3>
             <div className="p-5">
                <div className="flex items-center justify-between mb-4">
                    <div className="flex items-center gap-2 text-slate-600">
                        <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" strokeWidth={1.5} stroke="currentColor" className="w-5 h-5">
                          <path strokeLinecap="round" strokeLinejoin="round" d="M15 10.5a3 3 0 11-6 0 3 3 0 016 0z" />
                          <path strokeLinecap="round" strokeLinejoin="round" d="M19.5 10.5c0 7.142-7.5 11.25-7.5 11.25S4.5 17.642 4.5 10.5a7.5 7.5 0 1115 0z" />
                        </svg>
                        <span className="text-sm">Current</span>
                    </div>
                    <span className="font-semibold text-slate-900 bg-slate-100 px-3 py-1 rounded-md text-sm">Mumbai, India</span>
                </div>
                <div className="flex gap-3">
                  <button className="flex-1 py-2.5 border border-slate-200 rounded-xl text-slate-700 font-medium text-sm hover:bg-slate-50 transition-colors">
                      Change Location
                  </button>
                  <button className="flex-1 py-2.5 border border-slate-200 rounded-xl text-blue-600 font-medium text-sm hover:bg-blue-50 transition-colors flex items-center justify-center gap-1">
                      <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" strokeWidth={2} stroke="currentColor" className="w-4 h-4">
                        <path strokeLinecap="round" strokeLinejoin="round" d="M15.042 21.672L13.684 16.6m0 0l-2.51 2.225.569-9.47 5.227 7.917-3.286-.672zM12 2.25V4.5m5.834 1.666l-1.591 1.591M20.25 10.5H18M7.757 14.743l-1.59 1.59M6 10.5H3.75m4.007-4.243l-1.59-1.59" />
                      </svg>
                      Use GPS
                  </button>
                </div>
             </div>
        </section>

        {/* App Preferences */}
         <section className="bg-white rounded-2xl shadow-sm border border-slate-100 overflow-hidden">
            <h3 className="px-5 py-3 bg-slate-50/50 border-b border-slate-100 font-semibold text-slate-700 text-sm tracking-wide">PREFERENCES</h3>
            <div className="divide-y divide-slate-100">
                <div className="p-4 flex justify-between items-center">
                    <span className="text-slate-900 font-medium">Theme</span>
                    <select className="bg-slate-50 border border-slate-200 text-slate-700 rounded-lg text-sm px-3 py-1.5 focus:outline-none focus:ring-2 focus:ring-blue-500/50">
                        <option>Light</option>
                        <option>Dark</option>
                        <option>System</option>
                    </select>
                </div>
                 <div className="p-4 flex justify-between items-center">
                    <span className="text-slate-900 font-medium">Language</span>
                     <select className="bg-slate-50 border border-slate-200 text-slate-700 rounded-lg text-sm px-3 py-1.5 focus:outline-none focus:ring-2 focus:ring-blue-500/50">
                        <option>English</option>
                        <option>Hindi</option>
                        <option>Marathi</option>
                    </select>
                </div>
                <div className="p-4 flex justify-between items-center">
                    <span className="text-slate-900 font-medium">Data Refresh</span>
                     <select className="bg-slate-50 border border-slate-200 text-slate-700 rounded-lg text-sm px-3 py-1.5 focus:outline-none focus:ring-2 focus:ring-blue-500/50">
                        <option>Auto (Recommended)</option>
                        <option>Every 5 mins</option>
                        <option>Every 15 mins</option>
                        <option>Manual only</option>
                    </select>
                </div>
            </div>
        </section>

        {/* Account Actions */}
        <div className="space-y-3 pt-2">
             <button className="w-full bg-white p-4 rounded-xl border border-slate-200 text-left text-slate-700 font-medium shadow-sm flex justify-between items-center hover:bg-slate-50 transition-colors">
                <span>Privacy & Security</span>
                <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" strokeWidth={2} stroke="currentColor" className="w-4 h-4 text-slate-400">
                  <path strokeLinecap="round" strokeLinejoin="round" d="M8.25 4.5l7.5 7.5-7.5 7.5" />
                </svg>
            </button>
            <button className="w-full bg-white p-4 rounded-xl border border-slate-200 text-left text-slate-700 font-medium shadow-sm flex justify-between items-center hover:bg-slate-50 transition-colors">
                <span>Terms of Service</span>
                <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" strokeWidth={2} stroke="currentColor" className="w-4 h-4 text-slate-400">
                  <path strokeLinecap="round" strokeLinejoin="round" d="M8.25 4.5l7.5 7.5-7.5 7.5" />
                </svg>
            </button>
             <button className="w-full bg-white p-4 rounded-xl border border-red-100 text-left text-red-600 font-medium shadow-sm hover:bg-red-50 transition-colors flex justify-between items-center mt-4">
                <span>Log Out</span>
                <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" strokeWidth={2} stroke="currentColor" className="w-4 h-4">
                  <path strokeLinecap="round" strokeLinejoin="round" d="M15.75 9V5.25A2.25 2.25 0 0013.5 3h-6a2.25 2.25 0 00-2.25 2.25v13.5A2.25 2.25 0 007.5 21h6a2.25 2.25 0 002.25-2.25V15M12 9l-3 3m0 0l3 3m-3-3h12.75" />
                </svg>
            </button>
        </div>

        {/* Footer */}
        <div className="text-center pt-8 pb-4 opacity-70">
            <div className="flex items-center justify-center gap-2 mb-2">
                <div className="w-6 h-6 bg-blue-600 rounded-md flex items-center justify-center text-white font-bold text-xs shadow-sm">CL</div>
                <span className="font-bold text-slate-700 tracking-tight">CrisisLens</span>
            </div>
            <p className="text-xs text-slate-400 font-medium">Version 1.0.0 MVP</p>
        </div>
      </div>
    </div>
  );
};

export default ProfileScreen;