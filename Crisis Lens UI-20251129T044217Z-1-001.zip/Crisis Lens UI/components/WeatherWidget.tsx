import React, { useState, useEffect } from 'react';

interface WeatherData {
  temp: number;
  condition: string;
  humidity: number;
  windSpeed: number;
  location: string;
  icon?: string;
}

interface WeatherWidgetProps {
  locationQuery: string;
}

const WeatherWidget: React.FC<WeatherWidgetProps> = ({ locationQuery }) => {
  const [weather, setWeather] = useState<WeatherData | null>(null);
  const [loading, setLoading] = useState<boolean>(true);

  // Helper to get API key safely across Vite/CRA environments
  const getApiKey = () => {
    try {
      // Check Vite (import.meta.env)
      // We access it dynamically to avoid build errors in non-Vite environments
      if (typeof import.meta !== 'undefined' && (import.meta as any).env && (import.meta as any).env.VITE_WEATHER_API_KEY) {
        return (import.meta as any).env.VITE_WEATHER_API_KEY;
      }
      // Check Create React App (process.env)
      if (typeof process !== 'undefined' && process.env && process.env.REACT_APP_WEATHER_API_KEY) {
        return process.env.REACT_APP_WEATHER_API_KEY;
      }
    } catch (e) {
      // Ignore environment access errors
    }
    return '';
  };

  useEffect(() => {
    let isMounted = true;
    
    const fetchWeather = async () => {
      setLoading(true);
      const apiKey = getApiKey();
      
      // Fallback mock data
      const mockData: WeatherData = {
        temp: 28,
        condition: 'Mist',
        humidity: 78,
        windSpeed: 12,
        location: locationQuery || 'Mumbai',
        icon: '50d'
      };

      // If no API key is available, use mock data immediately without error
      if (!apiKey) {
        if (isMounted) {
          console.log("No Weather API key found, using mock data.");
          setWeather(mockData);
          setLoading(false);
        }
        return;
      }

      try {
        const res = await fetch(
          `https://api.openweathermap.org/data/2.5/weather?q=${encodeURIComponent(locationQuery || 'Mumbai')}&units=metric&appid=${apiKey}`
        );

        if (!res.ok) {
           throw new Error(`Weather API Error: ${res.statusText}`);
        }

        const data = await res.json();
        
        if (isMounted) {
          setWeather({
            temp: Math.round(data.main.temp),
            condition: data.weather[0].main,
            humidity: data.main.humidity,
            windSpeed: Math.round(data.wind.speed * 3.6), // convert m/s to km/h
            location: data.name,
            icon: data.weather[0].icon
          });
        }
      } catch (err) {
        console.warn("Weather fetch failed, falling back to mock data:", err);
        // Fallback to mock data on API failure
        if (isMounted) {
          setWeather(mockData);
        }
      } finally {
        if (isMounted) setLoading(false);
      }
    };

    fetchWeather();

    return () => { isMounted = false; };
  }, [locationQuery]);

  if (loading && !weather) {
    return (
      <div className="bg-white p-4 rounded-xl border border-slate-200 shadow-sm animate-pulse h-24 w-full">
         <div className="h-4 bg-slate-100 rounded w-1/3 mb-2"></div>
         <div className="h-8 bg-slate-100 rounded w-1/2"></div>
      </div>
    );
  }

  if (!weather) return null;

  return (
    <div className="bg-gradient-to-br from-blue-50 to-white p-4 rounded-xl border border-blue-100 shadow-sm flex items-center justify-between w-full">
      <div>
        <div className="flex items-center gap-2 mb-1">
           <h3 className="text-sm font-semibold text-slate-700 flex items-center gap-1">
             <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="currentColor" className="w-4 h-4 text-blue-500">
               <path fillRule="evenodd" d="M11.54 22.351l.07.04.028.016a.76.76 0 00.723 0l.028-.015.071-.041a16.975 16.975 0 001.144-.742 19.58 19.58 0 002.683-2.282c1.944-1.99 3.963-4.98 3.963-8.827a8.25 8.25 0 00-16.5 0c0 3.846 2.02 6.837 3.963 8.827a19.58 19.58 0 002.682 2.282 16.975 16.975 0 001.146.742zM12 13.5a3 3 0 100-6 3 3 0 000 6z" clipRule="evenodd" />
             </svg>
             {weather.location}
           </h3>
           <span className="text-xs text-slate-400 font-medium px-1.5 py-0.5 bg-white rounded border border-slate-100">Live</span>
        </div>
        <div className="flex items-end gap-2">
           <span className="text-3xl font-bold text-slate-900">{weather.temp}°</span>
           <span className="text-sm text-slate-600 font-medium mb-1.5">{weather.condition}</span>
        </div>
        <div className="text-xs text-slate-500 mt-1 flex gap-3">
           <span>Humidity: {weather.humidity}%</span>
           <span>Wind: {weather.windSpeed} km/h</span>
        </div>
      </div>
      
      <div className="w-16 h-16 bg-blue-100 rounded-full flex items-center justify-center shrink-0 ml-2">
         {weather.icon ? (
            <img 
              src={`https://openweathermap.org/img/wn/${weather.icon}@2x.png`} 
              alt={weather.condition} 
              className="w-16 h-16 drop-shadow-sm"
            />
         ) : (
            <span className="text-2xl">⛅</span>
         )}
      </div>
    </div>
  );
};

export default WeatherWidget;