import React, { useState, useRef, useEffect } from "react";
import { GoogleGenAI } from "@google/genai";
import { X, Send, MapPin, Loader2, Sparkles, Bot, ExternalLink } from "lucide-react";
import { UserLocation } from "../types";

interface Message {
  role: 'user' | 'model';
  text: string;
  sources?: { title: string; uri: string }[];
}

interface CrisisAssistantProps {
  currentLocation: UserLocation;
}

const CrisisAssistant: React.FC<CrisisAssistantProps> = ({ currentLocation }) => {
  const [isOpen, setIsOpen] = useState(false);
  const [input, setInput] = useState('');
  const [messages, setMessages] = useState<Message[]>([
    { role: 'model', text: 'Hello. I can help you find shelters, hospitals, or verify crisis information using Google Maps. What can I help you with today?' }
  ]);
  const [isLoading, setIsLoading] = useState(false);
  const messagesEndRef = useRef<HTMLDivElement>(null);

  const scrollToBottom = () => {
    messagesEndRef.current?.scrollIntoView({ behavior: "smooth" });
  };

  useEffect(() => {
    scrollToBottom();
  }, [messages, isOpen]);

  const handleSend = async () => {
    if (!input.trim() || isLoading) return;

    const userMsg = input;
    setInput('');
    setMessages(prev => [...prev, { role: 'user', text: userMsg }]);
    setIsLoading(true);

    try {
      const apiKey = (typeof process !== 'undefined' && process.env) 
        ? process.env.API_KEY 
        : '';

      if (!apiKey) {
        throw new Error("API Key not found");
      }

      const ai = new GoogleGenAI({ apiKey });
      
      const response = await ai.models.generateContent({
        model: "gemini-2.5-flash",
        contents: userMsg,
        config: {
          tools: [{ googleMaps: {} }],
          toolConfig: {
            retrievalConfig: {
              latLng: {
                latitude: currentLocation.lat,
                longitude: currentLocation.lng
              }
            }
          },
          systemInstruction: `You are a helpful crisis response assistant for the application CrisisLens. 
          The user is currently in ${currentLocation.city}, ${currentLocation.area}.

          CORE RESPONSIBILITIES:
          1. Provide accurate, location-based safety information using Google Maps (shelters, hospitals, relief centers).
          2. Prioritize official sources and human safety above all else.
          3. Keep responses concise and helpful for real-time queries.

          SCENARIO GENERATION MODE:
          If the user explicitly asks for "dummy data", "test scenarios", or "Q&A generation", switch to the following persona:
          "You are a crisis-response data generator. Create a set of Mumbai-specific emergency and crisis Q&A items using fictional (dummy) data. Provide 6–10 question-and-answer pairs. Cover topics such as flooding, medical emergencies, shelters, safety procedures, helpline contacts, transportation disruptions, and communication guidance during crisis events in Mumbai. Keep the answers short, practical, and easy for a safety assistant chatbot to read."
          `,
        }
      });

      const text = // response model compatibility: use first candidate text if available
        (response as any)?.candidates?.[0]?.content?.[0]?.text ||
        (response as any)?.text ||
        "I couldn't find an answer to that. Please check official local news.";

      const chunks = (response as any)?.candidates?.[0]?.groundingMetadata?.groundingChunks;
      const sources: { title: string; uri: string }[] = [];

      if (chunks) {
        chunks.forEach((chunk: any) => {
          if (chunk.web?.uri) {
            sources.push({ title: chunk.web.title || 'Web Source', uri: chunk.web.uri });
          }
          if (chunk.maps?.uri) {
             sources.push({ title: chunk.maps.title || 'Google Maps', uri: chunk.maps.uri });
          }
        });
      }

      setMessages(prev => [...prev, { role: 'model', text, sources }]);

    } catch (error) {
      console.error("Gemini API Error:", error);
      setMessages(prev => [...prev, { role: 'model', text: "I'm having trouble connecting to the network or verifying the API key. Please try again later." }]);
    } finally {
      setIsLoading(false);
    }
  };

  const handleKeyPress = (e: React.KeyboardEvent) => {
    if (e.key === 'Enter' && !e.shiftKey) {
      e.preventDefault();
      handleSend();
    }
  };

  return (
    <>
      {/* Floating Action Button */}
      <button
        onClick={() => setIsOpen(true)}
        className={`fixed bottom-20 right-4 sm:bottom-6 sm:right-6 z-40 flex items-center gap-2 px-3 py-2 bg-white border border-slate-200 text-slate-900 rounded-full shadow-lg transition-all duration-300 transform hover:scale-105 ${isOpen ? 'scale-0 opacity-0' : 'scale-100 opacity-100'}`}
        aria-label="Open Safety Check"
      >
        <Bot className="w-5 h-5 text-blue-600" />
        <span className="font-medium text-sm text-blue-600">Safety Check</span>
      </button>

      {/* Chat Interface */}
      <div 
        className={`fixed bottom-0 right-0 sm:bottom-6 sm:right-6 z-50 w-full sm:w-[380px] h-[100dvh] sm:h-[500px] bg-white sm:rounded-2xl shadow-2xl flex flex-col transition-all duration-300 origin-bottom-right ${
          isOpen ? 'opacity-100 scale-100 translate-y-0' : 'opacity-0 scale-95 translate-y-10 pointer-events-none'
        }`}
        role="dialog"
        aria-modal="true"
        aria-label="Safety Check chat"
      >
        {/* Header */}
        <div className="bg-slate-900 text-white p-4 sm:rounded-t-2xl flex items-center justify-between shrink-0">
          <div className="flex items-center gap-2">
            <div className="p-1.5 bg-blue-500 rounded-lg">
                <Bot className="w-5 h-5 text-white" />
            </div>
            <div>
              <h3 className="font-bold text-sm">Safety Check</h3>
              <p className="text-[10px] text-slate-300 flex items-center gap-1">
                <span className="text-[10px]">Powered by Gemini</span>
              </p>
            </div>
          </div>
          <button 
            onClick={() => setIsOpen(false)}
            className="p-1.5 hover:bg-slate-800 rounded-full transition-colors"
            aria-label="Close Safety Check"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Messages */}
        <div className="flex-1 overflow-y-auto p-4 space-y-4 bg-slate-50">
          {messages.map((msg, idx) => (
            <div key={idx} className={`flex ${msg.role === 'user' ? 'justify-end' : 'justify-start'}`}>
              <div 
                className={`max-w-[85%] rounded-2xl p-3 text-sm leading-relaxed shadow-sm ${
                  msg.role === 'user' 
                    ? 'bg-blue-600 text-white rounded-tr-sm' 
                    : 'bg-white text-slate-900 border border-slate-100 rounded-tl-sm'
                }`}
              >
                <div className="whitespace-pre-wrap">{msg.text}</div>
                
                {/* Sources */}
                {msg.sources && msg.sources.length > 0 && (
                  <div className="mt-3 pt-2 border-t border-slate-100/50 flex flex-wrap gap-2">
                    {msg.sources.map((source, sIdx) => (
                      <a 
                        key={sIdx}
                        href={source.uri}
                        target="_blank"
                        rel="noopener noreferrer"
                        className={`inline-flex items-center gap-1 px-2 py-1 rounded-md text-[10px] font-medium transition-colors ${
                            msg.role === 'user' 
                                ? 'bg-blue-700 text-blue-100 hover:bg-blue-800' 
                                : 'bg-slate-100 text-blue-600 hover:bg-blue-50 border border-blue-100'
                        }`}
                      >
                        <MapPin className="w-3 h-3" />
                        <span className="truncate max-w-[150px]">{source.title}</span>
                        <ExternalLink className="w-2.5 h-2.5 opacity-50" />
                      </a>
                    ))}
                  </div>
                )}
              </div>
            </div>
          ))}
          {isLoading && (
            <div className="flex justify-start">
              <div className="bg-white border border-slate-100 rounded-2xl rounded-tl-sm p-3 shadow-sm">
                <Loader2 className="w-5 h-5 text-blue-500 animate-spin" />
              </div>
            </div>
          )}
          <div ref={messagesEndRef} />
        </div>

        {/* Input */}
        <div className="p-3 bg-white border-t border-slate-100 shrink-0 sm:rounded-b-2xl">
          <div className="relative flex items-center">
            <textarea
              value={input}
              onChange={(e) => setInput(e.target.value)}
              onKeyDown={handleKeyPress}
              placeholder="Ask about shelters, hospitals..."
              className="w-full bg-slate-50 border border-slate-200 text-slate-900 placeholder-slate-400 text-sm rounded-xl pl-4 pr-12 py-3 focus:outline-none focus:ring-2 focus:ring-blue-500/20 focus:border-blue-500 resize-none max-h-24 no-scrollbar"
              rows={1}
            />
            <button
              onClick={handleSend}
              disabled={!input.trim() || isLoading}
              className="absolute right-2 p-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700 disabled:opacity-50 disabled:cursor-not-allowed transition-colors"
              aria-label="Send message"
            >
              <Send className="w-4 h-4" />
            </button>
          </div>
          <p className="text-[10px] text-center text-slate-400 mt-2">AI can make mistakes. Verify critical info.</p>
        </div>
      </div>
    </>
  );
};

export default CrisisAssistant;