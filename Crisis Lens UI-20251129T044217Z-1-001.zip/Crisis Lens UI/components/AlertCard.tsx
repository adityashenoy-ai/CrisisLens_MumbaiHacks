import React from 'react';
import { AlertItem } from '../data/db';

interface AlertCardProps {
  alert: AlertItem;
  isFollowing: boolean;
  onToggleFollow: (id: string) => void;
  onClick: (alert: AlertItem) => void;
}

const AlertCard: React.FC<AlertCardProps> = ({ alert, isFollowing, onToggleFollow, onClick }) => {
  // Helper for badge colors
  const getSeverityColor = (severity: string) => {
    switch (severity) {
      case "Critical": return "bg-red-100 text-red-600";
      case "High": return "bg-orange-100 text-orange-700";
      case "Moderate": return "bg-yellow-100 text-yellow-700";
      case "Low": return "bg-green-100 text-green-700";
      default: return "bg-gray-100 text-gray-700";
    }
  };

  const handleFollowClick = (e: React.MouseEvent) => {
    e.stopPropagation();
    onToggleFollow(alert.id);
  };

  return (
    <div 
      onClick={() => onClick(alert)}
      className="bg-white p-4 rounded-2xl shadow-sm border border-slate-100 flex flex-col gap-3 transition-transform hover:scale-[1.01] duration-200 cursor-pointer active:scale-[0.99]"
    >
      <div className="flex gap-4">
        {/* Image Thumbnail */}
        <div className="w-24 h-24 flex-shrink-0 rounded-xl overflow-hidden bg-slate-200 shadow-inner">
          <img 
            src={alert.imageUrl} 
            alt={alert.title} 
            className="w-full h-full object-cover"
          />
        </div>

        {/* Content */}
        <div className="flex-1 min-w-0">
          <div className="flex justify-between items-start mb-1">
            <h3 className="font-bold text-slate-900 leading-tight truncate pr-2">{alert.title}</h3>
          </div>
          
          <p className="text-xs text-slate-500 mb-2 line-clamp-2">{alert.summary}</p>
          
          <div className="flex flex-wrap gap-2 mb-2">
            <span className={`text-[10px] font-semibold px-2 py-0.5 rounded-full ${getSeverityColor(alert.severity)}`}>
              {alert.severity}
            </span>
            <span className="text-[10px] font-medium px-2 py-0.5 rounded-full bg-slate-100 text-slate-600">
              {alert.status}
            </span>
          </div>
        </div>
      </div>

      <div className="flex items-center justify-between mt-1 pt-2 border-t border-slate-50">
        <div className="text-[10px] text-slate-400 font-medium">
          {alert.distanceKm > 0 ? `${alert.distanceKm} km away` : 'National'} • Verified {alert.verifiedSources} sources
        </div>
        
        <button
          onClick={handleFollowClick}
          className={`px-4 py-1.5 text-xs font-semibold rounded-lg transition-colors border ${
            isFollowing
              ? "bg-slate-50 text-slate-600 border-slate-200"
              : "bg-white text-slate-900 border-slate-300 hover:bg-slate-50"
          }`}
        >
          {isFollowing ? "Following" : "Follow"}
        </button>
      </div>
    </div>
  );
};

export default AlertCard;