import React, { useState, useMemo } from 'react';
import { AlertItem } from '../data/db';
import AlertCard from './AlertCard';

interface AlertsScreenProps {
  alerts: AlertItem[];
  followedIds: string[];
  onToggleFollow: (id: string) => void;
  onAlertClick: (alert: AlertItem) => void;
  onNavigateHome: () => void;
}

const AlertsScreen: React.FC<AlertsScreenProps> = ({
  alerts,
  followedIds,
  onToggleFollow,
  onAlertClick,
  onNavigateHome
}) => {
  const [activeTab, setActiveTab] = useState<'Active' | 'Resolved' | 'All'>('Active');
  const [sortBy, setSortBy] = useState<'recent' | 'severity' | 'nearest'>('recent');

  const displayedAlerts = useMemo(() => {
    // 1. Filter by followed
    let filtered = alerts.filter(a => followedIds.includes(a.id));

    // 2. Filter by Tab
    if (activeTab === 'Active') {
      filtered = filtered.filter(a => !a.status.toLowerCase().includes('resolved'));
    } else if (activeTab === 'Resolved') {
      filtered = filtered.filter(a => a.status.toLowerCase().includes('resolved'));
    }

    // 3. Sort
    return filtered.sort((a, b) => {
      if (sortBy === 'severity') {
        const severityOrder: Record<string, number> = { Critical: 3, High: 2, Moderate: 1, Low: 0 };
        return (severityOrder[b.severity] || 0) - (severityOrder[a.severity] || 0);
      }
      if (sortBy === 'nearest') {
        return a.distanceKm - b.distanceKm;
      }
      // Recent (default)
      return new Date(b.timestamp).getTime() - new Date(a.timestamp).getTime();
    });
  }, [alerts, followedIds, activeTab, sortBy]);

  return (
    <div className="min-h-screen bg-slate-50 pb-24 animate-in fade-in duration-300">
      {/* Header */}
      <header className="bg-white sticky top-0 z-10 border-b border-slate-100 px-4 py-4 flex items-center justify-between shadow-sm">
        <h1 className="text-xl font-bold text-slate-800">Your Alerts</h1>
        <button className="p-2 bg-slate-50 rounded-full text-slate-600 hover:bg-slate-100">
           <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" strokeWidth={1.5} stroke="currentColor" className="w-5 h-5">
              <path strokeLinecap="round" strokeLinejoin="round" d="M10.34 15.84c-.688-.06-1.386-.09-2.09-.09H7.5a4.5 4.5 0 110-9h.75c.704 0 1.402-.03 2.09-.09m0 9.18c.253.996.946 1.93 1.814 2.8.626.626 1.445.966 2.298 1.148.168.037.338.074.508.106m-5.32-4.054a17.502 17.502 0 011.21-.825m0 0a17.5 17.5 0 012.05-1.112m-2.25 1.112c-.116-.58.076-1.127.44-1.63m2.25 1.112a17.505 17.505 0 01-1.25-1.4m0 0a17.502 17.502 0 00-2.3-2.1m2.3 2.1a17.503 17.503 0 001.12-2.06m-1.12 2.06c.42.345.895.736 1.411 1.18m-2.822-1.18l1.41-1.18" />
           </svg>
        </button>
      </header>

      {/* Controls */}
      <div className="px-4 py-4 space-y-4">
        {/* Tabs */}
        <div className="flex p-1 bg-slate-200/60 rounded-xl">
          {(['Active', 'Resolved', 'All'] as const).map((tab) => (
            <button
              key={tab}
              onClick={() => setActiveTab(tab)}
              className={`flex-1 py-2 text-sm font-medium rounded-lg transition-all ${
                activeTab === tab
                  ? 'bg-white text-slate-900 shadow-sm'
                  : 'text-slate-500 hover:text-slate-700'
              }`}
            >
              {tab}
            </button>
          ))}
        </div>

        {/* Sort */}
        <div className="flex items-center gap-2 overflow-x-auto no-scrollbar">
          <span className="text-xs font-medium text-slate-500 mr-1">Sort by:</span>
          {[
            { id: 'recent', label: 'Most Recent' },
            { id: 'severity', label: 'Severity' },
            { id: 'nearest', label: 'Nearest' }
          ].map((opt) => (
            <button
              key={opt.id}
              onClick={() => setSortBy(opt.id as any)}
              className={`px-3 py-1.5 rounded-full text-xs font-medium border whitespace-nowrap transition-colors ${
                sortBy === opt.id
                  ? 'bg-slate-800 text-white border-slate-800'
                  : 'bg-white text-slate-600 border-slate-200 hover:border-slate-300'
              }`}
            >
              {opt.label}
            </button>
          ))}
        </div>
      </div>

      {/* List */}
      <div className="px-4 space-y-4">
        {displayedAlerts.length > 0 ? (
          displayedAlerts.map(alert => (
            <AlertCard
              key={alert.id}
              alert={alert}
              isFollowing={true} // In this list, they are followed (unless filter removed, but card handles it)
              onToggleFollow={onToggleFollow}
              onClick={onAlertClick}
            />
          ))
        ) : (
          /* Empty State */
          <div className="flex flex-col items-center justify-center py-12 text-center px-6 mt-10">
            <div className="w-24 h-24 bg-blue-50 rounded-full flex items-center justify-center mb-6">
               <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" strokeWidth={1.5} stroke="currentColor" className="w-10 h-10 text-blue-400">
                  <path strokeLinecap="round" strokeLinejoin="round" d="M14.857 17.082a23.848 23.848 0 005.454-1.31A8.967 8.967 0 0118 9.75v-.7V9A6 6 0 006 9v.75a8.967 8.967 0 01-2.312 6.022c1.733.64 3.56 1.085 5.455 1.31m5.714 0a24.255 24.255 0 01-5.714 0m5.714 0a3 3 0 11-5.714 0" />
               </svg>
            </div>
            <h3 className="text-xl font-bold text-slate-800 mb-2">
              {followedIds.length === 0 ? "You're not following any crises" : "No alerts found"}
            </h3>
            <p className="text-slate-500 mb-8 max-w-xs leading-relaxed">
              {followedIds.length === 0 
                ? "Follow a crisis from the home screen to receive real-time updates and safety advice here."
                : "Try adjusting your filters to see your followed alerts."}
            </p>
            {followedIds.length === 0 && (
              <button
                onClick={onNavigateHome}
                className="px-8 py-3 bg-blue-600 text-white font-semibold rounded-xl hover:bg-blue-700 transition-colors shadow-lg shadow-blue-200"
              >
                Browse Crises
              </button>
            )}
          </div>
        )}
      </div>
    </div>
  );
};

export default AlertsScreen;