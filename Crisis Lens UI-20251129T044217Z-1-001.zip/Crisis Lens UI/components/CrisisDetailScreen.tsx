import React from 'react';
import { AlertItem } from '../data/db';
import VerificationPanel, { VerificationProps } from './VerificationPanel';

interface CrisisDetailScreenProps {
  alert: AlertItem;
  onBack: () => void;
  isFollowing: boolean;
  onToggleFollow: (id: string) => void;
}

const CrisisDetailScreen: React.FC<CrisisDetailScreenProps> = ({ alert, onBack, isFollowing, onToggleFollow }) => {
  
  const getSeverityColor = (severity: string) => {
    switch (severity) {
      case "Critical": return "bg-red-100 text-red-600";
      case "High": return "bg-orange-100 text-orange-700";
      case "Moderate": return "bg-yellow-100 text-yellow-700";
      case "Low": return "bg-green-100 text-green-700";
      default: return "bg-gray-100 text-gray-700";
    }
  };

  // Map alert data to the unified verification prop structure.
  // This ensures consistent UI for ALL alerts, removing any "Human" verification text.
  const verificationProps: VerificationProps = {
    crisisId: alert.id,
    sourcesCount: alert.verification ? alert.verification.evidence.length : alert.verifiedSources,
    lastVerified: alert.verification ? alert.verification.lastVerified : alert.lastVerified,
    severity: alert.severity
  };

  return (
    <div className="min-h-screen bg-white pb-10 animate-in fade-in slide-in-from-right-4 duration-300">
      
      {/* Header */}
      <header className="sticky top-0 z-20 bg-white/90 backdrop-blur-md border-b border-slate-100 px-4 py-3 flex items-center justify-between">
        <button 
          onClick={onBack}
          className="p-2 -ml-2 rounded-full hover:bg-slate-100 text-slate-700 transition-colors"
        >
          <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" strokeWidth={2} stroke="currentColor" className="w-6 h-6">
            <path strokeLinecap="round" strokeLinejoin="round" d="M10.5 19.5L3 12m0 0l7.5-7.5M3 12h18" />
          </svg>
        </button>
      </header>

      <div className="p-5 space-y-6">
        
        {/* Title Block */}
        <div>
          <h1 className="text-2xl font-bold text-slate-900 leading-tight mb-3">
            {alert.title}
          </h1>
          <div className="flex items-center justify-between mb-4">
            <div className="flex flex-col gap-1.5">
               <div className="text-sm text-slate-500 font-medium">
                 {alert.distanceKm > 0 ? `${alert.distanceKm} km away` : 'National Advisory'}
               </div>
               <div className="flex gap-2">
                 <span className={`px-2.5 py-0.5 rounded text-xs font-bold ${getSeverityColor(alert.severity)}`}>
                   {alert.severity}
                 </span>
                 <span className="px-2.5 py-0.5 rounded text-xs font-medium bg-slate-100 text-slate-600">
                   {alert.status}
                 </span>
               </div>
            </div>
            
            <button
              onClick={() => onToggleFollow(alert.id)}
              className={`px-6 py-2 rounded-lg text-sm font-semibold transition-all border ${
                isFollowing
                  ? "bg-slate-50 text-slate-600 border-slate-200"
                  : "bg-white text-slate-900 border-slate-300 hover:bg-slate-50"
              }`}
            >
              {isFollowing ? "Following" : "Follow"}
            </button>
          </div>
        </div>

        {/* What's Happening Now */}
        <div className="bg-slate-50 rounded-2xl p-6 border border-slate-100 shadow-[0_2px_8px_-2px_rgba(0,0,0,0.05)]">
          <div className="mb-3">
            <h2 className="font-bold text-slate-900 text-lg tracking-tight">What is happening now?</h2>
            <p className="text-xs text-slate-400 font-medium mt-1">
              Updated {alert.lastVerified}
            </p>
          </div>
          <p className="text-slate-700 leading-relaxed text-base">
            {alert.fullDescription || alert.summary}
          </p>
        </div>

        {/* Media */}
        <div className="rounded-2xl overflow-hidden shadow-sm border border-slate-100 aspect-video bg-slate-100">
           <img src={alert.imageUrl} alt={alert.title} className="w-full h-full object-cover" />
        </div>

        {/* Unified Verification Summary - Renders for ALL alerts */}
        <VerificationPanel verification={verificationProps} />

        {/* Recommended Actions */}
        <div>
            <h3 className="font-bold text-slate-900 mb-3 text-lg">What should you do?</h3>
            <ul className="space-y-3">
              {alert.recommendedActions.map((action, idx) => (
                <li key={idx} className="flex gap-3 text-sm text-slate-700 items-start">
                  <span className="mt-1.5 w-2 h-2 rounded-full bg-blue-500 flex-shrink-0"></span>
                  <span className="leading-relaxed">{action}</span>
                </li>
              ))}
              {alert.recommendedActions.length === 0 && (
                <li className="text-sm text-slate-500 italic">No specific actions available. Follow local authorities.</li>
              )}
            </ul>
        </div>

        {/* Timeline */}
        <div>
          <h3 className="font-bold text-slate-900 mb-4 text-lg">Timeline</h3>
          <div className="pl-2">
            {alert.timeline.map((event, index) => (
              <div key={event.id} className="relative pl-6 pb-8 last:pb-0 border-l border-dashed border-blue-200 last:border-transparent">
                <div className="absolute -left-1.5 top-0 w-3 h-3 rounded-full bg-blue-500 border-2 border-white shadow-sm z-10"></div>
                
                <div className="bg-blue-50/50 p-3 rounded-lg border border-blue-100 -mt-1">
                  <div className="flex justify-between items-start mb-1">
                    <span className="font-semibold text-slate-900 text-sm">{event.title}</span>
                    <span className="text-[10px] uppercase font-bold text-slate-400">{event.time}</span>
                  </div>
                  <p className="text-xs text-slate-600">{event.description}</p>
                </div>
              </div>
            ))}
          </div>
        </div>

      </div>
    </div>
  );
};

export default CrisisDetailScreen;