import React, { useEffect, useMemo, useState } from "react";
import { alertsDB } from "../data/db";
import CitySelector from "../components/CitySelector";
import AlertCard from "../components/AlertCard";
import BottomNav from "../components/BottomNav";
import { getFollowedIds, toggleFollow as toggleFollowLib } from "../lib/follows";

const LOC_KEY = "crisislens_location";
const DEFAULT_CITY = "Mumbai";

export default function HomeScreen() {
  const [search, setSearch] = useState("");
  const [scope, setScope] = useState<"local" | "national" | "international">("local");
  const [location, setLocation] = useState<string>(DEFAULT_CITY);
  const [followed, setFollowed] = useState<string[]>([]);

  useEffect(() => {
    // load persisted location
    try {
      const raw = localStorage.getItem(LOC_KEY);
      if (raw) setLocation(raw);
    } catch {}
    
    // load followed
    setFollowed(getFollowedIds());
  }, []);

  const handleLocationChange = (newLoc: string) => {
    setLocation(newLoc);
    try {
      localStorage.setItem(LOC_KEY, newLoc);
    } catch {}
  };

  const handleToggleFollow = (id: string) => {
    const newIds = toggleFollowLib(id);
    setFollowed(newIds);
  };

  const filteredAlerts = useMemo(() => {
    // basic matching: prefer alert.location includes selected city; else fallback to scope
    return alertsDB.filter((a) => {
      // search match
      const matchesSearch =
        !search ||
        a.title.toLowerCase().includes(search.toLowerCase()) ||
        a.summary.toLowerCase().includes(search.toLowerCase());

      // location match if alert has location field
      const hasLocation = (a as any).location;
      const matchesLocation = hasLocation
        ? (a as any).location.toLowerCase().includes(location.toLowerCase())
        : true;

      // Filter by scope
      // If scope is 'local', we enforce location match
      // If 'national' or 'international', we match the scope property directly
      let matchesScope = false;
      if (scope === 'local') {
          matchesScope = matchesLocation && a.scope === 'local';
      } else {
          matchesScope = a.scope === scope;
      }

      return matchesSearch && matchesScope;
    });
  }, [search, scope, location]);

  return (
    <div className="min-h-screen bg-slate-50 p-4 pb-24 font-sans">
      
      {/* 1. Header Section */}
      <div className="flex flex-col gap-2 mb-6">
        {/* Location Selector (Left Aligned) */}
        <div className="flex items-center">
           <CitySelector value={location} onChange={handleLocationChange} />
        </div>

        {/* Greeting */}
        <h1 className="text-xl font-bold text-slate-800 flex items-center gap-2 mt-1 px-1">
          Good Morning John <span className="text-yellow-500 text-lg">☀</span>
        </h1>
      </div>

      {/* 2. Search & Scope Row */}
      <div className="flex items-center gap-3 mb-6">
        {/* Search Input (Grows) */}
        <div className="relative flex-1">
          <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
            <svg className="w-5 h-5 text-slate-400" fill="none" viewBox="0 0 24 24" stroke="currentColor">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M21 21l-6-6m2-5a7 7 0 11-14 0 7 7 0 0114 0z" />
            </svg>
          </div>
          <input
            value={search}
            onChange={(e) => setSearch(e.target.value)}
            placeholder="Search"
            className="w-full pl-10 pr-4 py-3 rounded-2xl border border-slate-200 bg-white text-slate-900 placeholder-slate-400 focus:outline-none focus:ring-2 focus:ring-blue-400 text-sm shadow-sm transition-all"
          />
        </div>
        
        {/* Scope Dropdown (Compact Pill) */}
        <div className="relative">
          <select 
            value={scope}
            onChange={(e) => setScope(e.target.value as any)}
            className="appearance-none bg-white border border-slate-200 text-slate-900 font-medium py-3 pl-4 pr-10 rounded-2xl text-sm shadow-sm focus:outline-none focus:ring-2 focus:ring-blue-400 cursor-pointer"
          >
            <option value="local">Local</option>
            <option value="national">National</option>
            <option value="international">Global</option>
          </select>
          <div className="pointer-events-none absolute inset-y-0 right-0 flex items-center px-3 text-slate-500">
             <svg className="h-4 w-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M19 9l-7 7-7-7" />
             </svg>
          </div>
        </div>
      </div>

      {/* 3. Alerts Header */}
      <div className="mb-4 px-1">
        <h2 className="text-lg font-bold text-slate-900">
          {filteredAlerts.length} verified alerts
        </h2>
      </div>

      {/* 4. Alerts List */}
      <div className="space-y-4">
        {filteredAlerts.length === 0 ? (
          <div className="text-center py-16 bg-white rounded-2xl border border-slate-100 shadow-sm mx-1">
            <div className="w-12 h-12 bg-slate-100 rounded-full flex items-center justify-center mx-auto mb-3">
              <svg className="w-6 h-6 text-slate-400" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M13 16h-1v-4h-1m1-4h.01M21 12a9 9 0 11-18 0 9 9 0 0118 0z" />
              </svg>
            </div>
            <p className="text-slate-800 font-medium">No alerts found</p>
            <p className="text-slate-500 text-sm mt-1">There are no {scope} alerts for {location} right now.</p>
            {scope === 'local' && (
               <button 
                onClick={() => setScope('national')}
                className="mt-4 text-blue-600 text-sm font-semibold hover:underline"
              >
                Check National Alerts
              </button>
            )}
          </div>
        ) : (
          filteredAlerts.map((alert) => (
            <AlertCard 
              key={alert.id}
              alert={alert}
              isFollowing={followed.includes(alert.id)}
              onToggleFollow={handleToggleFollow}
              onClick={() => {
                // SPA navigation simulation
                // In a real router setup: navigate(`/alert/${alert.id}`)
                window.location.href = `/alert/${alert.id}`;
              }}
            />
          ))
        )}
      </div>

      {/* 5. Bottom Navigation */}
      <BottomNav 
        currentTab="Home" 
        onTabChange={(tab) => {
           if (tab === 'Alerts') window.location.href = '/alerts';
           if (tab === 'Profile') window.location.href = '/profile';
        }} 
      />
    </div>
  );
}