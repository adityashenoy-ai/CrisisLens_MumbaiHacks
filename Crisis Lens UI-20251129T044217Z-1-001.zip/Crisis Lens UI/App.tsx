import React, { useState, useMemo } from 'react';
import Header from './components/Header';
import AlertCard from './components/AlertCard';
import BottomNav from './components/BottomNav';
import SafetyAssistant from './components/SafetyAssistant';
import CrisisDetailScreen from './components/CrisisDetailScreen';
import AlertsScreen from './components/AlertsScreen';
import ProfileScreen from './components/ProfileScreen';
import { alertsDB, AlertItem } from './data/db';
import { Tab } from './types';
import { getFollowedIds, toggleFollow as toggleFollowLib } from './lib/follows';

const App: React.FC = () => {
  const [currentTab, setCurrentTab] = useState<Tab>('Home');
  const [search, setSearch] = useState("");
  const [scope, setScope] = useState<"local" | "national" | "international">("local");
  
  // Initialize from persistent storage
  const [followed, setFollowed] = useState<string[]>(() => getFollowedIds());
  
  const [isAssistantOpen, setIsAssistantOpen] = useState(false);
  const [selectedAlert, setSelectedAlert] = useState<AlertItem | null>(null);

  // Filter logic for Home
  const filteredAlerts = useMemo(() => {
    return alertsDB.filter((a) => {
      const matchesScope = a.scope === scope;
      const matchesSearch =
        a.title.toLowerCase().includes(search.toLowerCase()) ||
        a.summary.toLowerCase().includes(search.toLowerCase());
      return matchesScope && matchesSearch;
    });
  }, [search, scope]);

  const handleToggleFollow = (id: string) => {
    const newIds = toggleFollowLib(id);
    setFollowed(newIds);
  };

  // Detailed View Render
  if (selectedAlert) {
    return (
      <CrisisDetailScreen
        alert={selectedAlert}
        onBack={() => setSelectedAlert(null)}
        isFollowing={followed.includes(selectedAlert.id)}
        onToggleFollow={handleToggleFollow}
      />
    );
  }

  return (
    <div className="min-h-screen bg-slate-50">
      
      {/* Tab Content */}
      {currentTab === 'Home' && (
        <div className="pb-24">
            <Header />
            <main className="px-4 mt-2 space-y-5">
            
            {/* Search Bar */}
            <div className="relative">
              <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
                <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" strokeWidth={1.5} stroke="currentColor" className="w-5 h-5 text-slate-400">
                  <path strokeLinecap="round" strokeLinejoin="round" d="M21 21l-5.197-5.197m0 0A7.5 7.5 0 105.196 5.196a7.5 7.5 0 0010.607 10.607z" />
                </svg>
              </div>
              <input
                value={search}
                onChange={(e) => setSearch(e.target.value)}
                placeholder="Search updates, places, or keywords…"
                className="w-full pl-10 pr-4 py-3 rounded-xl border border-slate-300 bg-white text-slate-900 placeholder-slate-400 focus:outline-none focus:ring-2 focus:ring-blue-400 transition-all text-sm"
              />
            </div>

            {/* Filters/Actions */}
            <div className="flex justify-between items-center">
                <div className="relative inline-block">
                    <select 
                        value={scope}
                        onChange={(e) => setScope(e.target.value as any)}
                        className="appearance-none bg-white border border-slate-200 text-slate-700 py-2 pl-4 pr-10 rounded-full text-sm font-medium focus:outline-none focus:ring-2 focus:ring-blue-500/20"
                    >
                        <option value="local">Local</option>
                        <option value="national">National</option>
                        <option value="international">International</option>
                    </select>
                    <div className="pointer-events-none absolute inset-y-0 right-0 flex items-center px-3 text-slate-500">
                        <svg className="h-4 w-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M19 9l-7 7-7-7" />
                        </svg>
                    </div>
                </div>
                
                <button 
                    onClick={() => setIsAssistantOpen(true)}
                    className="flex items-center gap-1 text-sm font-medium text-blue-600 bg-blue-50 px-3 py-2 rounded-full hover:bg-blue-100 transition-colors"
                >
                    <span className="text-lg">🤖</span> Safety Check
                </button>
            </div>

            {/* Alert Count Header */}
            <div className="flex justify-between items-end">
              <h2 className="text-lg font-bold text-slate-800">
                {filteredAlerts.length} verified alerts
              </h2>
              <span className="text-xs text-slate-500 font-medium">Updated just now</span>
            </div>

            {/* Alert Feed */}
            <div className="space-y-4">
              {filteredAlerts.map((alert) => (
                <AlertCard 
                  key={alert.id} 
                  alert={alert} 
                  isFollowing={followed.includes(alert.id)}
                  onToggleFollow={handleToggleFollow}
                  onClick={(a) => setSelectedAlert(a)}
                />
              ))}
              
              {filteredAlerts.length === 0 && (
                <div className="text-center py-10 text-slate-500">
                    <p>No alerts found matching your criteria.</p>
                </div>
              )}
            </div>
          </main>
        </div>
      )}

      {currentTab === 'Alerts' && (
        <AlertsScreen 
          alerts={alertsDB}
          followedIds={followed}
          onToggleFollow={handleToggleFollow}
          onAlertClick={(a) => setSelectedAlert(a)}
          onNavigateHome={() => setCurrentTab('Home')}
        />
      )}

      {currentTab === 'Profile' && (
        <ProfileScreen />
      )}

      {/* Floating AI Assistant Modal */}
      <SafetyAssistant 
        isOpen={isAssistantOpen} 
        onClose={() => setIsAssistantOpen(false)} 
      />

      {/* Bottom Navigation */}
      <BottomNav currentTab={currentTab} onTabChange={setCurrentTab} />
    </div>
  );
};

export default App;