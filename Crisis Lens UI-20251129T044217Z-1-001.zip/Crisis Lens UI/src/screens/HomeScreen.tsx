
import React, { useEffect, useMemo, useState } from "react";
import { Link } from "react-router-dom";
import { alertsDB } from "../data/db";
import CitySelector from "../components/CitySelector";

const FOLLOW_KEY = "crisislens_followed";
const LOC_KEY = "crisislens_location";

export default function HomeScreen() {
  const [search, setSearch] = useState("");
  const [scope, setScope] = useState<"local" | "national" | "international">("local");
  const [location, setLocation] = useState<string>("Mumbai");
  const [followed, setFollowed] = useState<string[]>([]);

  // Persistence
  useEffect(() => {
    try {
      const storedFollow = localStorage.getItem(FOLLOW_KEY);
      if (storedFollow) setFollowed(JSON.parse(storedFollow));
      const storedLoc = localStorage.getItem(LOC_KEY);
      if (storedLoc) setLocation(storedLoc);
    } catch {}
  }, []);

  const handleLocationChange = (newLoc: string) => {
    setLocation(newLoc);
    try { localStorage.setItem(LOC_KEY, newLoc); } catch {}
  };

  const toggleFollow = (id: string) => {
    setFollowed((prev) => {
      const next = prev.includes(id) ? prev.filter(x => x !== id) : [...prev, id];
      try { localStorage.setItem(FOLLOW_KEY, JSON.stringify(next)); } catch {}
      return next;
    });
  };

  const filteredAlerts = useMemo(() => {
    const q = search.trim().toLowerCase();
    return alertsDB.filter((a) => {
      // Scope match
      if (scope === 'local') {
         if ((a as any).location && !((a as any).location as string).toLowerCase().includes(location.toLowerCase()) && a.scope === 'local') {
            return false;
         }
      } else if (a.scope !== scope) {
          return false;
      }

      // Search match
      if (!q) return true;
      return a.title.toLowerCase().includes(q) || a.summary.toLowerCase().includes(q);
    });
  }, [search, scope, location]);

  const verifiedCount = filteredAlerts.length;

  return (
    <div className="min-h-screen bg-white pb-28 font-sans">
      
      {/* 1. TOP SECTION */}
      <div className="pt-6 px-4 pb-4 bg-white">
        {/* Location Selector */}
        <div className="flex items-center mb-1">
          <CitySelector value={location} onChange={handleLocationChange} />
        </div>
        
        {/* Greeting */}
        <div className="text-2xl font-semibold text-slate-900 tracking-tight">
          Good Morning John <span className="text-xl">☀️</span>
        </div>
      </div>

      {/* 2. SEARCH + FILTERS */}
      <div className="px-4 mb-6 flex gap-3">
        <div className="relative flex-1">
          <input
            value={search}
            onChange={(e) => setSearch(e.target.value)}
            placeholder="Search"
            className="w-full h-12 pl-4 pr-4 rounded-2xl bg-slate-50 border border-slate-200 text-slate-900 placeholder-slate-400 focus:outline-none focus:ring-2 focus:ring-blue-500/20 focus:border-blue-500 transition-all text-base"
          />
        </div>
        
        <div className="relative">
          <select
            value={scope}
            onChange={(e) => setScope(e.target.value as any)}
            className="h-12 pl-4 pr-10 rounded-2xl bg-white border border-slate-200 text-slate-900 font-medium text-sm focus:outline-none focus:ring-2 focus:ring-blue-500/20 appearance-none"
          >
            <option value="local">Local</option>
            <option value="national">National</option>
            <option value="international">Global</option>
          </select>
          <div className="absolute inset-y-0 right-3 flex items-center pointer-events-none text-slate-500">
            <svg className="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M19 9l-7 7-7-7" /></svg>
          </div>
        </div>
      </div>

      {/* 3. VERIFIED ALERTS LIST */}
      <div className="px-4">
        <h3 className="text-sm font-semibold text-slate-500 mb-3 uppercase tracking-wider">
          {verifiedCount} verified alerts
        </h3>

        <div className="space-y-4">
          {filteredAlerts.length === 0 ? (
            <div className="text-center py-12 bg-slate-50 rounded-2xl border border-slate-100 border-dashed">
              <p className="text-slate-500 text-sm">No alerts found in this area.</p>
            </div>
          ) : (
            filteredAlerts.map((alert) => (
              <div key={alert.id} className="bg-white p-3 rounded-2xl border border-slate-100 shadow-sm flex gap-4 items-start">
                {/* Thumbnail */}
                <div className="w-20 h-20 bg-slate-100 rounded-xl flex-shrink-0 overflow-hidden">
                  <img src={alert.imageUrl} alt="" className="w-full h-full object-cover" />
                </div>

                {/* Content */}
                <div className="flex-1 min-w-0 py-0.5">
                  <div className="flex justify-between items-start gap-2">
                    <h4 className="font-bold text-slate-900 text-base leading-tight truncate">
                      {alert.title}
                    </h4>
                  </div>
                  
                  <p className="text-xs text-slate-500 mt-1 line-clamp-1">
                    {alert.summary}
                  </p>

                  <div className="flex items-center gap-2 mt-2">
                    <span className={`text-[10px] font-bold px-2 py-0.5 rounded-full uppercase tracking-wide ${
                      alert.severity === 'Critical' ? 'bg-red-50 text-red-700' :
                      alert.severity === 'High' ? 'bg-orange-50 text-orange-700' :
                      'bg-blue-50 text-blue-700'
                    }`}>
                      {alert.severity}
                    </span>
                    <span className="text-[10px] font-medium px-2 py-0.5 rounded-full bg-slate-100 text-slate-600">
                      {alert.status}
                    </span>
                  </div>
                  
                  <div className="mt-2 text-xs text-slate-400 font-medium">
                    {alert.distanceKm} km away
                  </div>
                </div>

                {/* Follow Button */}
                <div className="self-center">
                   <button
                    onClick={() => toggleFollow(alert.id)}
                    className={`h-8 px-3 rounded-lg text-xs font-semibold border transition-colors ${
                      followed.includes(alert.id)
                        ? "bg-slate-50 border-slate-200 text-slate-600"
                        : "bg-white border-slate-300 text-blue-600 hover:bg-blue-50"
                    }`}
                  >
                    {followed.includes(alert.id) ? "✓" : "Follow"}
                  </button>
                  <Link to={`/alert/${alert.id}`} className="block mt-2 text-center text-[10px] text-slate-400 hover:text-blue-600">
                    View
                  </Link>
                </div>
              </div>
            ))
          )}
        </div>
      </div>

      {/* 4. BOTTOM NAVIGATION */}
      <div className="fixed bottom-0 left-0 right-0 bg-white border-t border-slate-100 px-6 py-2 pb-safe flex justify-between items-center z-50">
        <Link to="/" className="flex flex-col items-center gap-1 p-2 text-blue-600">
          <svg className="w-6 h-6" fill="currentColor" viewBox="0 0 24 24"><path d="M12 2.25l-9.75 8.775v10.725h6.75v-6h6v6h6.75v-10.725l-9.75-8.775z" /></svg>
          <span className="text-[10px] font-semibold">Home</span>
        </Link>
        
        <Link to="/alerts" className="flex flex-col items-center gap-1 p-2 text-slate-400 hover:text-slate-600 transition-colors">
          <svg className="w-6 h-6" fill="none" stroke="currentColor" strokeWidth={2} viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" d="M15 17h5l-1.405-1.405A2.032 2.032 0 0118 14.158V11a6.002 6.002 0 00-4-5.659V5a2 2 0 10-4 0v.341C7.67 6.165 6 8.388 6 11v3.159c0 .538-.214 1.055-.595 1.436L4 17h5m6 0v1a3 3 0 11-6 0v-1m6 0H9" /></svg>
          <span className="text-[10px] font-semibold">Alerts</span>
        </Link>
        
        <Link to="/profile" className="flex flex-col items-center gap-1 p-2 text-slate-400 hover:text-slate-600 transition-colors">
          <svg className="w-6 h-6" fill="none" stroke="currentColor" strokeWidth={2} viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" d="M16 7a4 4 0 11-8 0 4 4 0 018 0zM12 14a7 7 0 00-7 7h14a7 7 0 00-7-7z" /></svg>
          <span className="text-[10px] font-semibold">Profile</span>
        </Link>
      </div>

    </div>
  );
}
