const KEY = "crisislens_followed";

export function getFollowedIds(): string[] {
  try {
    const raw = localStorage.getItem(KEY);
    if (!raw) return [];
    const parsed = JSON.parse(raw);
    return Array.isArray(parsed) ? parsed : [];
  } catch (e) {
    console.warn("getFollowedIds error", e);
    return [];
  }
}

export function setFollowedIds(ids: string[]) {
  try {
    localStorage.setItem(KEY, JSON.stringify(ids));
  } catch (e) {
    console.warn("setFollowedIds error", e);
  }
}

export function toggleFollow(id: string): string[] {
  const ids = getFollowedIds();
  const next = ids.includes(id) ? ids.filter(x => x !== id) : [...ids, id];
  setFollowedIds(next);
  return next;
}