
export interface TimelineEvent {
  id: string;
  title: string;
  description: string;
  time: string;
  type: 'report' | 'verification' | 'advisory' | 'alert' | 'citizen';
}

export interface VerificationEvidence {
  id: string;
  publisher: string;
  excerpt: string;
  similarity: number;
  independence: number;
  url: string;
}

export interface VerificationLog {
  time: string;
  text: string;
}

export interface VerificationData {
  claimId: string;
  status: "DRAFT" | "REVIEWED" | "PUBLISHED" | "ACTIVE_CRISIS" | "RESOLVED" | "ONGOING" | "ADVISORY";
  lastVerified: string;
  scores: {
    risk: number;
    l_truth: number;
    COR: number;
    CW: number;
  };
  reasoning_log: VerificationLog[];
  evidence: VerificationEvidence[];
  media_provenance: {
    status: string;
    score: number;
    thumbnails: string[];
  };
}

export interface AlertItem {
  id: string;
  title: string;
  summary: string;
  severity: "Critical" | "High" | "Moderate" | "Low";
  status: string;
  scope: "local" | "national" | "international";
  distanceKm: number;
  verifiedSources: number;
  lastVerified: string;
  timestamp: string;
  
  // Extended fields for UI
  fullDescription: string;
  imageUrl: string;
  recommendedActions: string[];
  timeline: TimelineEvent[];
  verification?: VerificationData; // New field for detailed verification panel
}

export const alertsDB: AlertItem[] = [
  {
    id: "1",
    title: "Flooding in Bandra East",
    summary: "Water levels rising due to heavy rainfall. Avoid low-lying areas.",
    fullDescription: "Water levels rising due to heavy rainfall. Several low-lying areas are reported to be waterlogged. Traffic is moving slowly.",
    severity: "Critical",
    status: "Active crisis",
    scope: "local",
    distanceKm: 2.5,
    verifiedSources: 3,
    lastVerified: "8 min ago",
    timestamp: new Date(Date.now() - 1000 * 60 * 8).toISOString(), // 8 mins ago
    imageUrl: "https://picsum.photos/seed/flood1/600/400",
    recommendedActions: [
      "Avoid low-lying areas.",
      "Expect heavy rain for the next 2 hours.",
      "Use elevated roads where possible.",
      "Follow municipal instructions."
    ],
    timeline: [
      {
        id: "t1",
        title: "Advisory issued",
        description: "Summary published after verification",
        time: "03:20 PM",
        type: "advisory"
      },
      {
        id: "t2",
        title: "Verification Completed",
        description: "AI agents review done",
        time: "03:18 PM",
        type: "verification"
      },
      {
        id: "t3",
        title: "Authorities alerted",
        description: "Water level rising rapidly",
        time: "03:05 PM",
        type: "alert"
      },
      {
        id: "t4",
        title: "First citizen report",
        description: "Flooded lane near station road",
        time: "02:47 PM",
        type: "citizen"
      }
    ],
    verification: {
      claimId: "clm_mumbai_flood_001",
      status: "PUBLISHED",
      lastVerified: new Date(Date.now() - 1000 * 60 * 8).toISOString(),
      scores: {
        risk: 87,
        l_truth: 0.94,
        COR: 0.72,
        CW: 0.81
      },
      reasoning_log: [
        { time: new Date(Date.now() - 1000 * 60 * 25).toISOString(), text: "Found 24 related items across public sources (3 independent publishers)" },
        { time: new Date(Date.now() - 1000 * 60 * 23).toISOString(), text: "NLI: p_entail=0.87 p_contradict=0.03 → l_truth=0.87" },
        { time: new Date(Date.now() - 1000 * 60 * 22).toISOString(), text: "Media reverse-search: matched older photo (2019) — penalize media score" },
        { time: new Date(Date.now() - 1000 * 60 * 20).toISOString(), text: "Corroboration COR=0.72; aggregated Risk=87 → Recommend ADVISORY" }
      ],
      evidence: [
        { id: "e1", publisher: "MumbaiTimes", excerpt: "Water levels rising in Bandra...", similarity: 0.92, independence: 0.95, url:"#" },
        { id: "e2", publisher: "CitizenPost", excerpt: "Local residents report submerged...", similarity: 0.88, independence: 0.9, url:"#" }
      ],
      media_provenance: {
        status: "likely_recycled",
        score: 0.93,
        thumbnails: ["https://picsum.photos/seed/flood1/100/100", "https://picsum.photos/seed/oldflood/100/100"]
      }
    }
  },
  {
    id: "2",
    title: "Waterlogging near Bandra East",
    summary: "Avoid low-lying roads. Traffic diverted via SV Road.",
    fullDescription: "Significant water accumulation reported near the station area. Municipal pumps are active.",
    severity: "Moderate",
    status: "Ongoing crisis",
    scope: "local",
    distanceKm: 2.5,
    verifiedSources: 12,
    lastVerified: "15 min ago",
    timestamp: new Date(Date.now() - 1000 * 60 * 15).toISOString(),
    imageUrl: "https://picsum.photos/seed/waterlog/600/400",
    recommendedActions: [
      "Use alternate routes.",
      "Drive carefully."
    ],
    timeline: [
      {
        id: "t2-1",
        title: "Traffic Alert",
        description: "Diversions in place",
        time: "02:30 PM",
        type: "alert"
      }
    ]
  },
  {
    id: "3",
    title: "Rainwater accumulation",
    summary: "Minor delays expected on main road due to slow drainage.",
    fullDescription: "Slow traffic movement due to water accumulation on the sides of the main carriageway.",
    severity: "Low",
    status: "Ongoing crisis",
    scope: "local",
    distanceKm: 2.5,
    verifiedSources: 5,
    lastVerified: "22 min ago",
    timestamp: new Date(Date.now() - 1000 * 60 * 22).toISOString(),
    imageUrl: "https://picsum.photos/seed/rain/600/400",
    recommendedActions: [
      "Plan for delays.",
      "Keep headlights on."
    ],
    timeline: [
        {
            id: "t3-1",
            title: "Report received",
            description: "User reported slow traffic",
            time: "01:00 PM",
            type: "report"
        }
    ]
  },
  {
    id: "4",
    title: "National Heavy Rain Advisory",
    summary: "Issued across Maharashtra region for the next 48 hours.",
    fullDescription: "The meteorological department has issued a heavy rain advisory for the coastal districts.",
    severity: "High",
    status: "Advisory",
    scope: "national",
    distanceKm: 0,
    verifiedSources: 5,
    lastVerified: "1 hour ago",
    timestamp: new Date(Date.now() - 1000 * 60 * 60).toISOString(),
    imageUrl: "https://picsum.photos/seed/storm/600/400",
    recommendedActions: [
      "Stay indoors if possible.",
      "Stock up on essentials."
    ],
    timeline: [
        {
            id: "t4-1",
            title: "Advisory Issued",
            description: "IMD bulletin released",
            time: "10:00 AM",
            type: "advisory"
        }
    ]
  },
  {
    id: "5",
    title: "Fire at Industrial Estate",
    summary: "Fire extinguished. Cooling operations completed.",
    fullDescription: "The fire reported at the industrial estate has been successfully put out by the fire brigade. No casualties reported.",
    severity: "Critical",
    status: "Resolved",
    scope: "local",
    distanceKm: 5.2,
    verifiedSources: 8,
    lastVerified: "2 hours ago",
    timestamp: new Date(Date.now() - 1000 * 60 * 120).toISOString(),
    imageUrl: "https://picsum.photos/seed/fire/600/400",
    recommendedActions: [
      "Area safe to enter.",
      "Follow traffic diversions if any."
    ],
    timeline: [
        {
            id: "t5-1",
            title: "Fire Extinguished",
            description: "Situation under control",
            time: "01:00 PM",
            type: "report"
        }
    ]
  }
];
